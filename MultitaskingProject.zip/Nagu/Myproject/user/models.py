from django.db import models

# Create your models here.
class scratching(models.Model):
    url=models.CharField(max_length=150)
    fname=models.CharField(max_length=150)
    pic=models.ImageField(upload_to='static/Scratching/', default="")

    def __str__(self):
        return self.fname
class qr_code(models.Model):
    url = models.CharField(max_length=150)
    fname = models.CharField(max_length=150)
    text = models.CharField(max_length=250)

    def __str__(self):
        return self.fname
class hand(models.Model):
    url = models.CharField(max_length=150)
    fname = models.CharField(max_length=150)
    text = models.CharField(max_length=250)

    def __str__(self):
        return self.fname
class reg(models.Model):
    name = models.CharField(max_length=200)
    fname = models.CharField(max_length=200)
    email = models.CharField(max_length=200)
    password = models.CharField(max_length=200)
    number = models.CharField(max_length=200)
    dob = models.DateField()
    pic=models.ImageField(upload_to='static/profile/', default="")

    def __str__(self):
        return self.name

class resize(models.Model):
    url=models.CharField(max_length=150)
    fname=models.CharField(max_length=150)
    pic=models.ImageField(upload_to='static/resize/', default="")

    def __str__(self):
        return self.url
class pdf(models.Model):
    url=models.CharField(max_length=150)
    fname=models.CharField(max_length=150)
    pic=models.ImageField(upload_to='static/resize/', default="")

    def __str__(self):
        return self.url
