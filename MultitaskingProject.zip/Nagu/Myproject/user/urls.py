from django.urls import path
from  . import views
urlpatterns=[
    path('home/',views.mainhome),
    path('',views.mainhome),
    path('qr_code/',views.home),
    path('about/',views.about),
    path('contact/',views.contact),
    path('register/',views.register),
    path('login/',views.login),
    path('student/',views.student),
    path('game/',views.game),
    path('feedback/',views.feedback),
    path('developer/',views.developer),
    path('scratching/',views.sc),
    path('handwriting/',views.hand1),
    path('compiler/',views.index),
    path('runcode/',views.runcode),
    path('resize/',views.resiz),
    path('pdf_convert/',views.convert),
    path('logout/',views.logout),
    path('My_Profile/',views.profile),

]
