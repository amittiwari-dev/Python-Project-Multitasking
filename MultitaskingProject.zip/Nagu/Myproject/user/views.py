import pathlib as path

from django.db import connection
from django.shortcuts import render
from .models import  *
from django.http import HttpResponse
import cv2
import os
import shutil
import sys
# Create your views here.

#use for profile genrated
def home(request):
    if request.method=='POST':
            bu=request.POST.get("btn","");
            massg=request.POST.get("txt")
            fname=request.POST.get("fname")
            url1=request.POST.get("url")
            qr_code(url=url1, fname=fname ,text=massg).save()
            if(bu=="On"):
                import pyqrcode
                import os, shutil
                file_name_svg = f"{fname}.svg"

                url = pyqrcode.create(massg)
                url.svg(file_name_svg, scale=8)


                os.mkdir(fr"{url1}{fname}")
                # shutil.move(f"{file_name_png}", fr"{url1}{fname}")
                shutil.move(f"{file_name_svg}", fr"{url1}{fname}")
                return HttpResponse("<script>alert('Qr_Code Genreted .. Check your drive');window.location.href='/user/home/'</script>")
    return render(request ,'user/home.html')
# user for scratching images code
def sc(request):
 if request.session.get('user'):
    if request.method == 'POST':
        bu = request.POST.get("btn")
        file1 = request.FILES['fle']
        fnam = request.POST.get("fname")
        url1 = request.POST.get("url1")
        scratching(url=url1,fname=fnam,pic=file1).save()
        print("")
        if (bu == "On"):
            from builtins import set
            import pathlib as path
            img1 = cv2.imread(f"static/Scratching/{file1}")
           # img1=cv2.imread("static/Scratching/Screenshot_2024-10-01_223303_F6WI65Z.png")
           # print(image)
            grey_filter = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
           # cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            invert = cv2.bitwise_not(grey_filter)
            blur = cv2.GaussianBlur(invert, (21, 21), 0)
            invertedblur = cv2.bitwise_not(blur)

            sketch_filter = cv2.divide(grey_filter, invertedblur, scale=256.0)
            # write to the image
            c = f"{fnam}.png"
            os.mkdir(fr"{url1}{fnam}")
            cv2.imwrite(c, sketch_filter)
            shutil.move(f"{c}", fr"{url1}{fnam}")
            return HttpResponse("<script>alert('Your Scratching created .. Choice your drive');window.location.href='/user/scratching/'</script>")
    return render(request,'user/num.html')
 else:
            return HttpResponse("<script>alert('Please login first to use Scratching.');window.location.href='/user/login';</script>")

def hand1(request):
    if request.session.get('user'):
     if request.method=='POST':
            bu=request.POST.get("btn","")
            text=request.POST.get("txt")
            fname = request.POST.get("fname")
            url1 = request.POST.get("url1")
            hand(url=url1, fname=fname ,text=text). save()
            if(bu=="On"):
                try:
                    import pywhatkit as pw
                    txt = text
                    c = f"{fname}.png"
                    os.mkdir(fr"{url1}{fname}")
                    pw.text_to_handwriting(txt, f"{fname}.png" , [0, 0, 0])
                    shutil.move(f"{c}", fr"{url1}{fname}")
                    return HttpResponse("<script>alert('Your Hand write created .. Choice your drive');window.location.href='/user/handwriting/'</script>")
                except:
                    return HttpResponse(
                        "<script>alert('Now This time you can not use hand writing words!! this is under procees for upgrade');window.location.href='/user/handwriting/'</script>")

     return render(request,'user/hand.html')
    else:
     return HttpResponse("<script>alert('Please login first to use Hand Writing.');window.location.href='/user/login';</script>")


def index(request):
    if request.session.get('user'):
            return render(request, 'user/index.html')
    else:
            return HttpResponse("<script>alert('Please login first to use compiler.');window.location.href='/user/login';</script>")

def runcode(request):

    if request.method == "POST":
        codeareadata = request.POST['codearea']

        try:
            #save original standart output reference

            original_stdout = sys.stdout
            sys.stdout = open('file.txt.txt','w') #change the standard output to the file.txt we created
            #execute code

            exec(codeareadata) # example=> print('hello world')
            sys.stdout.close()
            sys.stdout = original_stdout #reset the standard output its original value
            #finally read output from file.txt and save in output variable

            output = open('file.txt.txt','r').read()


        except Exception as e:
            #to return error in the code
            sys.stdout = original_stdout
            output = e

    #finally return and render index page and send codedata and output to show on page

    return render(request, 'user/index.html',{"data":codeareadata , "output":output})
def mainhome(request):
    return render(request, 'user/mainhome.html')
def about(request):
    return render(request, 'user/about.html')
def contact(request):
    return render(request,'user/contact.html')
def register(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        fname = request.POST.get("fname")
        email = request.POST.get("email")
        password = request.POST.get("passwd")
        phone = request.POST.get("num")
        dob = request.POST.get("dob")
        profile = request.FILES['ppic']
        reg( name=name, fname=fname, email=email,password=password,number=phone,dob=dob,pic=profile).save()
        return HttpResponse("<script>alert('Your Registion Successfull .....');window.location.href='/user/login/'</script>")

    return render(request,'user/register.html')
def login(request):
    if request.method == 'POST':
        uname = request.POST.get('email', "")
        password = request.POST.get('passwd', "")
        checkuser = reg.objects.filter(email=uname, password=password)
        print(checkuser)
        if (checkuser):
            request.session["user"] = uname
            return HttpResponse("<script>alert('LoginIn Successfully');window.location.href='/user/home'</script>")
        else:
            return HttpResponse(
                "<script>alert('UserId or Password is incorrect');window.location.href='/user/login'</script>")
    return render(request,'user/login.html')
def student(request):
    return render(request,'user/student.html')
def game(request):
    return render(request,'user/game.html')
def feedback(request):
    return render(request,'user/feedback.html')
def developer(request):
    return render(request,'user/developer.html')
def resiz(request):
    if request.method == 'POST':
        bu = request.POST.get("btn")
        file1 = request.FILES['file']
        url1 = request.POST.get("url1")
        fname = request.POST.get("name")
        resize(url=url1, fname=fname, pic=file1).save()

        if(bu=="On"):
            from PIL import Image

            filepath = (f"static/resize/{file1}")

            picture = Image.open(filepath)
            os.mkdir(fr"{url1}{fname}")
            a=f"{fname}.jpg"
            picture.save(f"{a}", "JPEG", optimize=True, quality=20)
            shutil.move(f"{a}", fr"{url1}{fname}")


            return HttpResponse("<script>alert('Resize Genreted .. Choice your drive');window.location.href='/user/resize/'</script>")

    return render(request,'user/resize.html')
def convert(request):
        if request.method == 'POST':
           bu = request.POST.get("btn")
           file1 = request.FILES['file']
           url1 = request.POST.get("url1")
           fname = request.POST.get("name")
           pdf(url=url1, fname=fname, pic=file1).save()
           if (bu == "On"):
             from PIL import Image
             import os
             filename = (f"static/resize/{file1}")
             image = Image.open(filename)
             if image.mode == "RGBA":
                image = image.convert("RGB")
             output = f"{fname}.pdf"
             os.mkdir(fr"{url1}{fname}")
             if os.path.exists(filename):
                image.save(output, "PDF", resolution=100.0)
             shutil.move(f"{output}", fr"{url1}{fname}")
             return HttpResponse("<script>alert('PDF Genreted .. Choice your drive');window.location.href='/user/pdf_convert/'</script>")
        return render(request, 'user/pdf.html')
def logout(request):
    del request.session['user']
    return HttpResponse("<script>alert('Logout Successfully');window.location.href='/user/home'</script>")
def profile(request):
    if request.session.get('user'):
        id=request.session.get('user')
        userdata=reg.objects.filter(email=id)[0:1]
        return render(request,'user/myprofile.html',{"a":userdata})
    else:
        return HttpResponse("<script>alert('Please login first to show your profile.');window.location.href='/user/login';</script>")
