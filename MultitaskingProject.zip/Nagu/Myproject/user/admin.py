from django.contrib import admin
from .models import *
# Register your models here.
class scartchingAdmin(admin.ModelAdmin):
    list_display = ("url","fname","pic")
admin.site.register(scratching,scartchingAdmin)
class qr_codeAdmin(admin.ModelAdmin):
    list_display = ("url","fname","text")
admin.site.register(qr_code,qr_codeAdmin)
class handAdmin(admin.ModelAdmin):
    list_display = ("url","fname","text")
admin.site.register(hand,handAdmin)
class regAdmin(admin.ModelAdmin):
    list_display = ("name","fname","email","password","number","dob","pic")
admin.site.register(reg,regAdmin)
class resizeAdmin(admin.ModelAdmin):
    list_display = ("url","fname","pic")
admin.site.register(resize,resizeAdmin)
class pdfAdmin(admin.ModelAdmin):
    list_display = ("url","fname","pic")
admin.site.register(pdf,pdfAdmin)